﻿using animezz.MVC.model;
using System.ComponentModel.DataAnnotations.Schema;

namespace animezz.MVC.DTO
{
    public class FranquiaDTO
    {
        public string? nome { get; set; }
        public string? sinopse { get; set; }

    }
}
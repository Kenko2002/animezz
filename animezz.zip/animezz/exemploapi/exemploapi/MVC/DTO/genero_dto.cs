﻿using animezz.MVC.model;
using System.ComponentModel.DataAnnotations.Schema;

namespace animezz.MVC.DTO
{
    public class GeneroDTO
    {
        public string? nome { get; set; }

    }
}